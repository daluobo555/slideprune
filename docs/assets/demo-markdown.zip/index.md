# 专注力学习资料 · The science of focus

正文为 PDF 提取文字，阅读顺序和公式可能需要校对；原页图片仅作参考。

## 原始页 2

![原始页 2](images/page-0002.png)

FIELD NOTES \/ 01 \/ START  
Less repetition\. More understanding\.  
A tiny lecture about making room to think\.  
SLIDEPRUNE \/ ORIGINAL DEMO  
12  
pages to explore  
Some pages repeat\.  
Some add an idea\.  
Some changes must stay\.

## 原始页 5

![原始页 5](images/page-0005.png)

FIELD NOTES \/ 02 \/ BUILD  
A useful learning loop  
An idea grows one step at a time\.  
SLIDEPRUNE \/ ORIGINAL DEMO  
1  
NOTICE  
Make the main idea visible\.  
2  
CONNECT  
Connect it to something you know\.  
3  
RECALL  
Try explaining it without looking\.

## 原始页 6

![原始页 6](images/page-0006.png)

FIELD NOTES \/ 03 \/ LOOK CLOSELY  
A disappearing mark matters  
Same words\. Different visual information\. Keep both states\.  
SLIDEPRUNE \/ ORIGINAL DEMO  
A B C  
A visual change can carry the whole lesson\.

## 原始页 7

![原始页 7](images/page-0007.png)

FIELD NOTES \/ 03 \/ LOOK CLOSELY  
A disappearing mark matters  
Same words\. Different visual information\. Keep both states\.  
SLIDEPRUNE \/ ORIGINAL DEMO  
A B C  
A visual change can carry the whole lesson\.

## 原始页 8

![原始页 8](images/page-0008.png)

FIELD NOTES \/ 04 \/ COMPARE  
One number can change the plan  
Similar layout does not mean identical content\.  
SLIDEPRUNE \/ ORIGINAL DEMO  
12  
minutes of focused review  
CHECK WHAT CHANGED

## 原始页 9

![原始页 9](images/page-0009.png)

FIELD NOTES \/ 04 \/ COMPARE  
One number can change the plan  
Similar layout does not mean identical content\.  
SLIDEPRUNE \/ ORIGINAL DEMO  
18  
minutes of focused review  
CHECK WHAT CHANGED

## 原始页 11

![原始页 11](images/page-0011.png)

FIELD NOTES \/ 05 \/ KEEP THE SIGNAL  
Your attention is a limited resource\.  
Use fewer pages when the ideas are truly the same\.  
SLIDEPRUNE \/ ORIGINAL DEMO  
Review the differences\.  
Keep what carries meaning\.  
Let the repetition go\.

## 原始页 12

![原始页 12](images/page-0012.png)

FIELD NOTES \/ 06 \/ TAKEAWAY  
Make a handout you can think on\.  
A clean page is only useful when the important details survive\.  
SLIDEPRUNE \/ ORIGINAL DEMO  
Review each suggestion  
Restore anything you need  
Leave room for your own notes
